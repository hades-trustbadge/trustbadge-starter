import { useEffect, useState } from "react";
import { useRouter } from "next/router";

export default function ProtectedPage() {
  const [verified, setVerified] = useState(false);
  const router = useRouter();

  useEffect(() => {
    const token = localStorage.getItem("wld_verified");
    if (!token) router.push("/");
    else setVerified(true);
  }, []);

  if (!verified) return null;

  return (
    <div style={{ padding: "2rem" }}>
      <h1>Bem-vindo ao conteúdo protegido do TrustBadge</h1>
    </div>
  );
}
