import VerifyWithWorldID from "../components/VerifyWithWorldID";

export default function Home() {
  return (
    <main style={{ padding: "2rem" }}>
      <h1>TrustBadge</h1>
      <p>Verifique sua identidade com World ID</p>
      <VerifyWithWorldID />
    </main>
  );
}
