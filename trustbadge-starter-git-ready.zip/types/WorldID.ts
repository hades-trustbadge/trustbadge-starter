// Tipagens podem ser expandidas conforme necessidade
