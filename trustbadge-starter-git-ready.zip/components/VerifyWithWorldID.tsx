"use client";
import { IDKitWidget, ISuccessResult } from "@worldcoin/idkit";
import { useRouter } from "next/router";

export default function VerifyWithWorldID() {
  const router = useRouter();

  const onSuccess = async (result: ISuccessResult) => {
    localStorage.setItem("wld_verified", "true");

    const res = await fetch("/api/verify", {
      method: "POST",
      body: JSON.stringify(result),
      headers: { "Content-Type": "application/json" },
    });

    if (res.ok) router.push("/protected");
    else alert("Verificação falhou");
  };

  return (
    <IDKitWidget
      app_id={process.env.NEXT_PUBLIC_WLD_APP_ID!}
      action="trustbadge_access"
      onSuccess={onSuccess}
    >
      {({ open }) => <button onClick={open}>Verificar com World ID</button>}
    </IDKitWidget>
  );
}
