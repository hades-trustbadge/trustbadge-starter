// Em versões futuras, adicionaremos configs globais aqui
