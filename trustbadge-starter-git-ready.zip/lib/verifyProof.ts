// Em versões futuras, aqui faremos a verificação real com a Worldcoin API
